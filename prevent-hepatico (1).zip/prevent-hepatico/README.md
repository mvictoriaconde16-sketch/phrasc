# prevent-hepatico

Calculadora em Java do risco cardiovascular em 10 anos pelo AHA PREVENT (modelo base), com um modificador hepático baseado em GGT, FIB-4 e razão AST/ALT. Replica a planilha `PREVENT_HEPATICO`.

Referência do PREVENT: Khan SS et al. *Development and Validation of the AHA's PREVENT Equations.* Circulation. 2024;149:430-449.

## Equação

```
Z_final = Z_PREVENT + Z_hep
risco (%) = exp(Z_final) / (1 + exp(Z_final)) * 100
```

`Z_PREVENT` usa os β oficiais por sexo para CVD total, ASCVD e insuficiência cardíaca.

```
Z_hep = β_GGT * (ln(GGT) - ln(25))
      + 0,35 * (ln(FIB-4) - ln(1,3))
      + 0,25 * max(0, FIB-4 - 2,67)
      + β_AST/ALT * ln(AST/ALT)
```

| Marcador | β feminino | β masculino |
|---|---|---|
| ln(GGT) | 0,20 | 0,25 |
| ln(FIB-4) | 0,35 | 0,35 |
| FIB-4 acima de 2,67 | 0,25 | 0,25 |
| ln(AST/ALT) | 0,10 | 0,18 |

Os β hepáticos são calibrações exploratórias a partir da literatura (Fraser 2014; UK Biobank 2022; Vieira Barbosa, AJG 2022). Não são coeficientes oficiais do PREVENT e não foram validados em coorte.

## Uso

```java
Paciente p = new Paciente();
p.masculino = true;
p.idade = 55;
p.colTotal = 203;   // mg/dL
p.hdl = 50;         // mg/dL
p.pas = 140;        // mmHg
p.imc = 27.0;
p.egfr = 80;        // CKD-EPI 2021
p.diabetes = false;
p.tabagismo = false;
p.antiHipertensivo = true;
p.estatina = false;
p.ggt = 90;         // U/L, 0 se não informado
p.fib4 = 1.8;
p.astAlt = 1.1;     // 0 se não informado

double base  = PreventHepatico.riscoBase(p, Desfecho.CVD_TOTAL);
double final_ = PreventHepatico.riscoFinal(p, Desfecho.CVD_TOTAL);
List<String> avisos = PreventHepatico.avisos(p);
```

Desfechos: `CVD_TOTAL`, `ASCVD`, `IC`.

## Build e testes

```
mvn test
mvn compile exec:java -Dexec.mainClass=br.ufpa.preventhepatico.PreventHepatico
```

Requer Java 17 ou superior e Maven.

## Limites

- Validado para 30-79 anos. `avisos()` lista entradas fora das faixas de validação, mas o cálculo não é bloqueado.
- Os modelos com HbA1c e UACR não estão implementados. O modificador hepático foi aplicado só aos três modelos base.
- Ferramenta de pesquisa. Não substitui julgamento clínico.

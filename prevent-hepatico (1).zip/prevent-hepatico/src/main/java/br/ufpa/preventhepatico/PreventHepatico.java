package br.ufpa.preventhepatico;

import java.util.ArrayList;
import java.util.List;

/**
 * AHA PREVENT (Khan et al., Circulation 2024;149:430-449), modelo base de 10 anos,
 * com modificador hepatico (GGT, FIB-4, AST/ALT) somado ao preditor linear Z.
 *
 * Risco final = exp(Z + Z_hep) / (1 + exp(Z + Z_hep)) * 100
 *
 * Replica a planilha PREVENT_HEPATICO (abas CALCULADORA, COEFICIENTES, COEF_HEPATICOS).
 */
public class PreventHepatico {

    public enum Desfecho { CVD_TOTAL, ASCVD, IC }

    public static class Paciente {
        public boolean masculino;
        public double idade;          // anos (validado 30-79)
        public double colTotal;       // mg/dL
        public double hdl;            // mg/dL
        public double pas;            // mmHg
        public double imc;            // kg/m2
        public double egfr;           // mL/min/1.73m2 (CKD-EPI 2021)
        public boolean diabetes;
        public boolean tabagismo;
        public boolean antiHipertensivo;
        public boolean estatina;
        public double ggt;            // U/L (0 = nao informado)
        public double fib4;           // escore
        public double astAlt;         // razao AST/ALT (0 = nao informado)
    }

    // Ordem: {CVD F, CVD M, ASCVD F, ASCVD M, IC F, IC M}
    private static final double[] IDADE    = {0.793933, 0.768853, 0.719883, 0.709985, 0.899823, 0.897264};
    private static final double[] NAO_HDL  = {0.030524, 0.073617, 0.117697, 0.165866, 0, 0};
    private static final double[] HDL      = {-0.160686, -0.095443, -0.151185, -0.114429, 0, 0};
    private static final double[] PAS_LO   = {-0.2394, -0.434735, -0.083536, -0.283721, -0.455977, -0.681147};
    private static final double[] PAS_HI   = {0.360078, 0.336266, 0.359285, 0.323998, 0.35765, 0.363446};
    private static final double[] DM       = {0.86676, 0.769286, 0.834858, 0.71896, 1.038346, 0.923776};
    private static final double[] FUMO     = {0.536074, 0.438687, 0.483108, 0.395697, 0.583916, 0.502374};
    private static final double[] IMC_LO   = {0, 0, 0, 0, -0.007229, -0.048584};
    private static final double[] IMC_HI   = {0, 0, 0, 0, 0.299771, 0.372693};
    private static final double[] EGFR_LO  = {0.604592, 0.537898, 0.486462, 0.369007, 0.745164, 0.692692};
    private static final double[] EGFR_HI  = {0.043377, 0.016483, 0.039778, 0.020362, 0.055709, 0.025183};
    private static final double[] ANTI_HAS = {0.315167, 0.288879, 0.226531, 0.203652, 0.353444, 0.298092};
    private static final double[] ESTATINA = {-0.147765, -0.133735, -0.059237, -0.086558, 0, 0};
    private static final double[] AHAS_PAS = {-0.066361, -0.047592, -0.039576, -0.032292, -0.098151, -0.049773};
    private static final double[] EST_NHDL = {0.119788, 0.150273, 0.084442, 0.114563, 0, 0};
    private static final double[] ID_NHDL  = {-0.081972, -0.051787, -0.056784, -0.03, 0, 0};
    private static final double[] ID_HDL   = {0.030677, 0.019117, 0.032569, 0.023275, 0, 0};
    private static final double[] ID_PAS   = {-0.094635, -0.104948, -0.103598, -0.092702, -0.094666, -0.12892};
    private static final double[] ID_DM    = {-0.27057, -0.225195, -0.241754, -0.201852, -0.358104, -0.304092};
    private static final double[] ID_FUMO  = {-0.078715, -0.089507, -0.079114, -0.097053, -0.115945, -0.140169};
    private static final double[] ID_IMC   = {0, 0, 0, 0, -0.003878, 0.006813};
    private static final double[] ID_EGFR  = {-0.163781, -0.15437, -0.167149, -0.121708, -0.188429, -0.179778};
    private static final double[] CONST    = {-3.307728, -3.031168, -3.819975, -3.500655, -4.310409, -3.946391};

    private static final double MG_DL_PARA_MMOL = 38.67;

    // Coeficientes hepaticos (aba COEF_HEPATICOS)
    private static final double B_GGT_F = 0.20, B_GGT_M = 0.25;
    private static final double CENTRO_LN_GGT = 3.21888;   // ln(25)
    private static final double B_FIB4 = 0.35;
    private static final double CENTRO_LN_FIB4 = 0.26236;  // ln(1.3)
    private static final double B_FIB4_EXTRA = 0.25;       // por unidade acima de 2.67
    private static final double LIMIAR_FIB4 = 2.67;
    private static final double B_AST_ALT_F = 0.10, B_AST_ALT_M = 0.18;

    private static int coluna(Desfecho d, boolean masculino) {
        return d.ordinal() * 2 + (masculino ? 1 : 0);
    }

    /** Preditor linear Z do PREVENT base. */
    public static double zBase(Paciente p, Desfecho d) {
        int k = coluna(d, p.masculino);

        double idade   = (p.idade - 55) / 10.0;
        double naoHdl  = (p.colTotal - p.hdl) / MG_DL_PARA_MMOL - 3.5;
        double hdl     = (p.hdl / MG_DL_PARA_MMOL - 1.3) / 0.3;
        double pasLo   = (Math.min(p.pas, 110) - 110) / 20.0;
        double pasHi   = (Math.max(p.pas, 110) - 130) / 20.0;
        double imcLo   = (Math.min(p.imc, 30) - 25) / 5.0;
        double imcHi   = (Math.max(p.imc, 30) - 30) / 5.0;
        double egfrLo  = (Math.min(p.egfr, 60) - 60) / -15.0;
        double egfrHi  = (Math.max(p.egfr, 60) - 90) / -15.0;
        double dm      = p.diabetes ? 1 : 0;
        double fumo    = p.tabagismo ? 1 : 0;
        double ahas    = p.antiHipertensivo ? 1 : 0;
        double est     = p.estatina ? 1 : 0;

        return IDADE[k] * idade
             + NAO_HDL[k] * naoHdl
             + HDL[k] * hdl
             + PAS_LO[k] * pasLo
             + PAS_HI[k] * pasHi
             + DM[k] * dm
             + FUMO[k] * fumo
             + IMC_LO[k] * imcLo
             + IMC_HI[k] * imcHi
             + EGFR_LO[k] * egfrLo
             + EGFR_HI[k] * egfrHi
             + ANTI_HAS[k] * ahas
             + ESTATINA[k] * est
             + AHAS_PAS[k] * ahas * pasHi
             + EST_NHDL[k] * est * naoHdl
             + ID_NHDL[k] * idade * naoHdl
             + ID_HDL[k] * idade * hdl
             + ID_PAS[k] * idade * pasHi
             + ID_DM[k] * idade * dm
             + ID_FUMO[k] * idade * fumo
             + ID_IMC[k] * idade * imcHi
             + ID_EGFR[k] * idade * egfrLo
             + CONST[k];
    }

    /** Modificador hepatico Z_hep (mesmo valor somado aos tres desfechos). */
    public static double zHepatico(Paciente p) {
        double z = 0;
        if (p.ggt > 0) {
            z += (p.masculino ? B_GGT_M : B_GGT_F) * (Math.log(p.ggt) - CENTRO_LN_GGT);
        }
        z += B_FIB4 * (Math.log(Math.max(p.fib4, 0.01)) - CENTRO_LN_FIB4);
        z += B_FIB4_EXTRA * Math.max(0, p.fib4 - LIMIAR_FIB4);
        if (p.astAlt > 0) {
            z += (p.masculino ? B_AST_ALT_M : B_AST_ALT_F) * Math.log(Math.max(p.astAlt, 0.01));
        }
        return z;
    }

    /** Risco em 10 anos, em %, para Z qualquer. */
    public static double risco(double z) {
        return Math.exp(z) / (1 + Math.exp(z)) * 100.0;
    }

    /** PREVENT base (%). */
    public static double riscoBase(Paciente p, Desfecho d) {
        return risco(zBase(p, d));
    }

    /** PREVENT + hepatico (%): risco estimado final. */
    public static double riscoFinal(Paciente p, Desfecho d) {
        return risco(zBase(p, d) + zHepatico(p));
    }

    /** Avisos de uso fora da faixa de validacao do PREVENT. */
    public static List<String> avisos(Paciente p) {
        List<String> a = new ArrayList<>();
        if (p.idade < 30 || p.idade > 79) a.add("Idade fora da faixa validada (30-79 anos).");
        if (p.colTotal < 130 || p.colTotal > 320) a.add("Colesterol total fora de 130-320 mg/dL.");
        if (p.hdl < 20 || p.hdl > 100) a.add("HDL fora de 20-100 mg/dL.");
        if (p.pas < 90 || p.pas > 180) a.add("PAS fora de 90-180 mmHg.");
        if (p.imc < 18.5 || p.imc > 39.9) a.add("IMC fora de 18,5-39,9 kg/m2.");
        if (p.egfr < 15 || p.egfr > 140) a.add("eGFR fora de 15-140 mL/min.");
        return a;
    }

    public static String categoria(double r) {
        if (r < 5) return "Baixo";
        if (r < 7.5) return "Limitrofe";
        if (r < 20) return "Intermediario";
        return "Alto";
    }

    public static void main(String[] args) {
        Paciente p = new Paciente();
        p.masculino = true;
        p.idade = 24;
        p.colTotal = 203;
        p.hdl = 50;
        p.pas = 140;
        p.imc = 18.2;
        p.egfr = 30;
        p.diabetes = true;
        p.tabagismo = true;
        p.antiHipertensivo = true;
        p.estatina = true;
        p.ggt = 400;
        p.fib4 = 4.0;
        p.astAlt = 0.7;

        for (String aviso : avisos(p)) System.out.println("AVISO: " + aviso);
        System.out.printf("Z_hep = %.5f%n", zHepatico(p));
        for (Desfecho d : Desfecho.values()) {
            double base = riscoBase(p, d);
            double fin = riscoFinal(p, d);
            System.out.printf("%-10s base %.2f%% | final %.2f%% | delta %+.2f pp | %s%n",
                    d, base, fin, fin - base, categoria(fin));
        }
    }
}

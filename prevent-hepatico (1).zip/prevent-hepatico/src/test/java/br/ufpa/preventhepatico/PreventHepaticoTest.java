package br.ufpa.preventhepatico;

import static org.junit.jupiter.api.Assertions.assertEquals;

import br.ufpa.preventhepatico.PreventHepatico.Desfecho;
import br.ufpa.preventhepatico.PreventHepatico.Paciente;
import org.junit.jupiter.api.Test;

class PreventHepaticoTest {

    private Paciente exemplo(double imc, double astAlt) {
        Paciente p = new Paciente();
        p.masculino = true;
        p.idade = 24;
        p.colTotal = 203;
        p.hdl = 50;
        p.pas = 140;
        p.imc = imc;
        p.egfr = 30;
        p.diabetes = true;
        p.tabagismo = true;
        p.antiHipertensivo = true;
        p.estatina = true;
        p.ggt = 400;
        p.fib4 = 4.0;
        p.astAlt = astAlt;
        return p;
    }

    @Test
    void valoresCorretosDoExemplo() {
        Paciente p = exemplo(18.2, 0.7);
        assertEquals(1.35482, PreventHepatico.zHepatico(p), 1e-4);
        assertEquals(37.19, PreventHepatico.riscoBase(p, Desfecho.CVD_TOTAL), 0.01);
        assertEquals(69.65, PreventHepatico.riscoFinal(p, Desfecho.CVD_TOTAL), 0.01);
        assertEquals(45.25, PreventHepatico.riscoFinal(p, Desfecho.ASCVD), 0.01);
        assertEquals(66.85, PreventHepatico.riscoFinal(p, Desfecho.IC), 0.01);
    }

    @Test
    void reproduzCacheDaPlanilhaComCelulasEmTexto() {
        Paciente p = exemplo(30, 0.01);
        assertEquals(0.59009, PreventHepatico.zHepatico(p), 1e-4);
        assertEquals(51.65, PreventHepatico.riscoFinal(p, Desfecho.CVD_TOTAL), 0.01);
        assertEquals(45.56, PreventHepatico.riscoFinal(p, Desfecho.IC), 0.01);
    }
}
